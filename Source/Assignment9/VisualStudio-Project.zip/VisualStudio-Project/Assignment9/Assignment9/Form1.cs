using System.Collections;
using System.Diagnostics;

namespace Assignment9
{
    public partial class Form1 : Form
    {

        private ArrayList RATFiles;
        private Process RATProcess;
        private bool HasScanned = false;

        public Form1()
        {
            InitializeComponent();

            outputBox.SelectionStart = outputBox.Text.Length;
            outputBox.ScrollToCaret();
        }

        private void Form1_Load(object sender, EventArgs e) { }

        private void scanBtn_Click(object sender, EventArgs e)
        {
            HasScanned = true;
            RATFiles = DetectRATFiles();
            RATProcess = DetectRATProcess();

            outputBox.Text += "Scanning...\r\n";

            if (RATFiles == null)
                outputBox.Text += "No njRAT files detected.\r\n";

            // There are njRAT files
            else
            {
                outputBox.Text += "The following njRAT files were found:\r\n";
                foreach (string path in RATFiles)
                    outputBox.Text += $"\t{path}\r\n";
          
            } // end njRAT files found

            if (RATProcess == null)
                outputBox.Text += "njRAT process not found running.\r\n";

            // There is an njRAT process
            else
            {
                outputBox.Text += "The following njRAT process was found running:\r\n";
                outputBox.Text += $"\t{RATProcess.MainModule.FileName}\r\n";
            }

            outputBox.Text += "Scan Finished.\r\n\r\n";

        } // end scanBtn_Click func



        private void removeBtn_Click(object sender, EventArgs e)
        {
            if (!HasScanned)
            {
                outputBox.Text += "Please scan before attempting to remove.\r\n";
                return;
            }


            if (RATProcess == null)
                outputBox.Text += "No process to stop. Moving on...\r\n";

            // There is a njRAT process to kill
            else
            {
                outputBox.Text += $"Killing njRAT Process (PID: {RATProcess.Id})... ";
                RATProcess.Kill();
                outputBox.Text += "Done.\r\n";

            } // end process kill else


            if (RATFiles == null)
                outputBox.Text += "No files to remove.\r\n";

            // There are njRAT files to delete
            else
            {
                outputBox.Text += "Deleting Files...\r\n";
                foreach (string file in RATFiles)
                {
                    FileInfo fileInfo = new FileInfo(file);
                    if (fileInfo.IsReadOnly)
                        File.SetAttributes(file, ~FileAttributes.ReadOnly);

                    File.Delete(file);
                    outputBox.Text += $"\t{file} deleted.\r\n";
                }
                outputBox.Text += "Done.\r\n";
            } // end files to delete else


            if (RATProcess == null && RATFiles == null)
                outputBox.Text += "No known version of njRAT running.\r\n";

            HasScanned = false;
            outputBox.Text += "Finished Removal Process.\r\n\r\n";

        } // end removeBtn_Click func




        private Process DetectRATProcess()
        {
            string malwareName = "windows";
            Process[] AllProcesses = Process.GetProcesses();

            foreach (Process proc in AllProcesses)
                if (proc.ProcessName == malwareName)
                    return proc;

            return null;
        } // end DetectRATProcess func

        private ArrayList DetectRATFiles()
        {

            string temp = Path.GetTempPath();
            string startup = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            startup = $"{startup}\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup";

            ArrayList ExistingFiles = new ArrayList();

            string[] Indicators = [
                "C:\\njq8.exe",
                "C:\\njRAT.exe",
                $"{temp}\\windows.exe",
                $"{temp}\\windows.tmp",
                $"{temp}\\windows.exe.tmp", // Can't remember the exact filename :)
                $"{startup}\\ecc7c8c51c0850c1ec247c7fd3602f20.exe"
            ];

            foreach (string FilePath in Indicators)
            {
                if (File.Exists(FilePath))
                    ExistingFiles.Add(FilePath);
            }


            // Return the files found
            if (ExistingFiles.Count > 0)
                return ExistingFiles;

            return null;
        } // end DetectRAT func

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
